// Copyright 2018 Roman Vasyutin romanvas3008@gmail.com

#ifndef INCLUDE_BUILDER_HPP_
#define INCLUDE_BUILDER_HPP_

class Builder{
public:
  Builder();
private:

};

#endif // INCLUDE_BUILDER_HPP_
